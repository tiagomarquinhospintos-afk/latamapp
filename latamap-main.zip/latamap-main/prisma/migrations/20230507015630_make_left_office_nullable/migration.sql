-- AlterTable
ALTER TABLE "Leader" ALTER COLUMN "leftOffice" DROP NOT NULL;
